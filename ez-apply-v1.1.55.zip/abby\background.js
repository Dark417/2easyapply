const DEFAULT_PARAMS = {
    searches: ['California, United States'],
    selectedSearch: 'California, United States',
    ignore: {
        caseSensitive: false,
        keywords: ['founding', 'machine learning']
    },
    linkedin: {
        filters: ['Easy Apply'],
        clickCount: 2,
        minClickDelaySeconds: 0.8
    },
    auto: {
        delaysSec: {
            nextJobItem: { min: 0.4, max: 1.1 },
            clickEasyApply: { min: 0.4, max: 1.2 },
            easyApplyScroll: { min: 0.6, max: 1.6 },
            inputFields: { min: 0.2, max: 0.7 },
            nextStep: { min: 0.5, max: 1.3 },
            submitPageScroll: { min: 1.0, max: 2.0 },
            closeSubmitPage: { min: 0.6, max: 1.4 }
        },
        rateLimits: { perMinute: 5, perHour: 30, perDay: 200 },
        burstRest: { every: 5, minSeconds: 5, maxSeconds: 10 }
    },
    customRegex: ['in office']
};

function mergeDeep(base, patch) {
    const merged = Object.assign({}, base || {});
    Object.entries(patch || {}).forEach(([key, value]) => {
        if (value && typeof value === 'object' && !Array.isArray(value) && merged[key] && typeof merged[key] === 'object' && !Array.isArray(merged[key])) {
            merged[key] = mergeDeep(merged[key], value);
        } else {
            merged[key] = value;
        }
    });
    return merged;
}

function normalizeParams(raw) {
    const params = mergeDeep(DEFAULT_PARAMS, raw || {});
    params.searches = Array.from(new Set((params.searches || []).map(v => String(v || '').trim()).filter(Boolean)));
    if (!params.searches.length) params.searches = [...DEFAULT_PARAMS.searches];
    params.selectedSearch = String(params.selectedSearch || '').trim() || params.searches[0];
    params.ignore = mergeDeep(DEFAULT_PARAMS.ignore, params.ignore || {});
    params.ignore.keywords = Array.from(new Set((params.ignore.keywords || []).map(v => String(v || '').trim()).filter(Boolean)));
    params.linkedin = mergeDeep(DEFAULT_PARAMS.linkedin, params.linkedin || {});
    params.linkedin.filters = Array.from(new Set((params.linkedin.filters || []).map(v => String(v || '').trim()).filter(Boolean)));
    params.linkedin.clickCount = Math.max(1, parseInt(params.linkedin.clickCount, 10) || DEFAULT_PARAMS.linkedin.clickCount);
    params.linkedin.minClickDelaySeconds = Math.max(0, Number(params.linkedin.minClickDelaySeconds) || DEFAULT_PARAMS.linkedin.minClickDelaySeconds);
    params.auto = mergeDeep(DEFAULT_PARAMS.auto, params.auto || {});
    const legacyMinSec = Math.max(0, (parseInt(params.auto?.delaysMs?.min, 10) || 300) / 1000);
    const legacyMaxSec = Math.max(legacyMinSec, (parseInt(params.auto?.delaysMs?.max, 10) || 1200) / 1000);
    const normalizeRange = (range, fallback) => {
        const min = Math.max(0, Number(range?.min ?? fallback.min));
        const max = Math.max(min, Number(range?.max ?? fallback.max));
        return { min: Number(min.toFixed(2)), max: Number(max.toFixed(2)) };
    };
    params.auto.delaysSec = {
        nextJobItem: normalizeRange(params.auto.delaysSec?.nextJobItem, { min: legacyMinSec || DEFAULT_PARAMS.auto.delaysSec.nextJobItem.min, max: legacyMaxSec || DEFAULT_PARAMS.auto.delaysSec.nextJobItem.max }),
        clickEasyApply: normalizeRange(params.auto.delaysSec?.clickEasyApply, { min: legacyMinSec || DEFAULT_PARAMS.auto.delaysSec.clickEasyApply.min, max: legacyMaxSec || DEFAULT_PARAMS.auto.delaysSec.clickEasyApply.max }),
        easyApplyScroll: normalizeRange(params.auto.delaysSec?.easyApplyScroll, DEFAULT_PARAMS.auto.delaysSec.easyApplyScroll),
        inputFields: normalizeRange(params.auto.delaysSec?.inputFields, DEFAULT_PARAMS.auto.delaysSec.inputFields),
        nextStep: normalizeRange(params.auto.delaysSec?.nextStep, { min: legacyMinSec || DEFAULT_PARAMS.auto.delaysSec.nextStep.min, max: legacyMaxSec || DEFAULT_PARAMS.auto.delaysSec.nextStep.max }),
        submitPageScroll: normalizeRange(params.auto.delaysSec?.submitPageScroll, DEFAULT_PARAMS.auto.delaysSec.submitPageScroll),
        closeSubmitPage: normalizeRange(params.auto.delaysSec?.closeSubmitPage, DEFAULT_PARAMS.auto.delaysSec.closeSubmitPage)
    };
    params.auto.rateLimits = mergeDeep(DEFAULT_PARAMS.auto.rateLimits, params.auto.rateLimits || {});
    params.auto.rateLimits.perMinute = Math.max(1, parseInt(params.auto.rateLimits.perMinute, 10) || DEFAULT_PARAMS.auto.rateLimits.perMinute);
    params.auto.rateLimits.perHour = Math.max(params.auto.rateLimits.perMinute, parseInt(params.auto.rateLimits.perHour, 10) || DEFAULT_PARAMS.auto.rateLimits.perHour);
    params.auto.rateLimits.perDay = Math.max(params.auto.rateLimits.perHour, parseInt(params.auto.rateLimits.perDay, 10) || DEFAULT_PARAMS.auto.rateLimits.perDay);
    params.auto.burstRest = mergeDeep(DEFAULT_PARAMS.auto.burstRest, params.auto.burstRest || {});
    params.auto.burstRest.every = Math.max(1, parseInt(params.auto.burstRest.every, 10) || DEFAULT_PARAMS.auto.burstRest.every);
    params.auto.burstRest.minSeconds = Math.max(0, Number(params.auto.burstRest.minSeconds) || DEFAULT_PARAMS.auto.burstRest.minSeconds);
    params.auto.burstRest.maxSeconds = Math.max(params.auto.burstRest.minSeconds, Number(params.auto.burstRest.maxSeconds) || DEFAULT_PARAMS.auto.burstRest.maxSeconds);
    params.customRegex = Array.from(new Set((params.customRegex || []).map(v => String(v || '').trim()).filter(Boolean)));
    return params;
}

function storageGet(keys) {
    return new Promise(resolve => chrome.storage.local.get(keys, resolve));
}

function storageSet(values) {
    return new Promise(resolve => chrome.storage.local.set(values, resolve));
}

async function loadParams() {
    const stored = await storageGet(['abbyParams']);
    return normalizeParams(stored.abbyParams || {});
}

async function saveParams(patch) {
    const current = await loadParams();
    const next = normalizeParams(mergeDeep(current, patch || {}));
    await storageSet({ abbyParams: next });
    return next;
}

function buildSearchUrl(params) {
    return 'https://www.linkedin.com/jobs/search/';
}

function waitForTabComplete(tabId, timeoutMs = 20000) {
    return new Promise((resolve, reject) => {
        const startedAt = Date.now();
        const onUpdated = (updatedTabId, info) => {
            if (updatedTabId !== tabId) return;
            if (info.status === 'complete') {
                chrome.tabs.onUpdated.removeListener(onUpdated);
                resolve();
            }
        };
        chrome.tabs.onUpdated.addListener(onUpdated);
        chrome.tabs.get(tabId, (tab) => {
            if (chrome.runtime.lastError) {
                chrome.tabs.onUpdated.removeListener(onUpdated);
                reject(new Error(chrome.runtime.lastError.message));
                return;
            }
            if (tab?.status === 'complete') {
                chrome.tabs.onUpdated.removeListener(onUpdated);
                resolve();
                return;
            }
            const timer = setInterval(() => {
                if (Date.now() - startedAt > timeoutMs) {
                    clearInterval(timer);
                    chrome.tabs.onUpdated.removeListener(onUpdated);
                    reject(new Error('Timed out waiting for LinkedIn search tab to load.'));
                }
            }, 250);
        });
    });
}

async function runLinkedInSearchSetup(tabId, params) {
    const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        func: async (runtimeParams) => {
            const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));
            const keyword = 'software engineer';
            const location = String(runtimeParams.selectedSearch || runtimeParams.searches?.[0] || 'California, United States').trim();
            const clean = (value) => String(value || '').replace(/\s+/g, ' ').trim();
            const fillInput = (input, value) => {
                if (!input) return false;
                input.focus();
                input.value = '';
                input.dispatchEvent(new Event('input', { bubbles: true }));
                input.value = value;
                input.dispatchEvent(new Event('input', { bubbles: true }));
                input.dispatchEvent(new Event('change', { bubbles: true }));
                return true;
            };
            const getSearchInputs = () => {
                const inputs = Array.from(document.querySelectorAll('input[role="combobox"], input[type="text"], input'));
                const keywordInput = inputs.find(node => /title, skill, or company/i.test(node.getAttribute('aria-label') || node.placeholder || ''));
                const locationInput = inputs.find(node => /city, state, or zip code/i.test(node.getAttribute('aria-label') || node.placeholder || ''));
                return { keywordInput, locationInput };
            };
            const findSearchButton = () => Array.from(document.querySelectorAll('button')).find(button => {
                const text = clean(button.innerText || button.textContent || button.getAttribute('aria-label') || '');
                return /^search$/i.test(text) && !button.closest('[role="dialog"]');
            }) || null;
            const findAllFiltersButton = () => Array.from(document.querySelectorAll('button, [role="button"]')).find(node => {
                const text = clean(node.innerText || node.textContent || node.getAttribute('aria-label') || '');
                return /show all filters|^all filters$/i.test(text);
            }) || null;
            const findShowResultsButton = () => Array.from(document.querySelectorAll('button, [role="button"]')).find(node => {
                const text = clean(node.innerText || node.textContent || node.getAttribute('aria-label') || '');
                return /^show results$/i.test(text) || /show results/i.test(text);
            }) || null;
            const findEasyApplyToggle = (scope = document) => {
                const root = scope || document;
                return Array.from(root.querySelectorAll('button, [role="switch"], [role="checkbox"], label, input[type="checkbox"], span, div')).find(node => {
                    const text = clean(node.innerText || node.textContent || node.getAttribute('aria-label') || '');
                    return /easy apply/i.test(text);
                }) || null;
            };
            const isToggleOn = (node) => {
                if (!node) return false;
                if (node.tagName === 'INPUT' && node.type === 'checkbox') return node.checked;
                if (node.getAttribute('aria-pressed') === 'true' || node.getAttribute('aria-checked') === 'true') return true;
                const checkbox = node.querySelector?.('input[type="checkbox"]');
                if (checkbox?.checked) return true;
                return /selected|checked|active|on/i.test(String(node.className || ''));
            };
            const clickToggle = (node) => {
                if (!node) return false;
                if (node.tagName === 'INPUT' && node.type === 'checkbox') {
                    node.checked = true;
                    ['click', 'input', 'change'].forEach(eventName => node.dispatchEvent(new Event(eventName, { bubbles: true })));
                    return true;
                }
                node.click();
                return true;
            };
            const openAllFilters = async () => {
                const allFiltersButton = findAllFiltersButton();
                if (!allFiltersButton) return false;
                allFiltersButton.click();
                const startedAt = Date.now();
                while (Date.now() - startedAt < 5000) {
                    if (findShowResultsButton()) return true;
                    await wait(200);
                }
                return false;
            };
            const pickLocationSuggestion = async () => {
                const startedAt = Date.now();
                while (Date.now() - startedAt < 5000) {
                    const listbox = document.querySelector('[role="listbox"]');
                    const options = Array.from((listbox || document).querySelectorAll('[role="option"]')).filter(node => clean(node.innerText || node.textContent || ''));
                    const first = options[0];
                    if (first) {
                        first.click();
                        return clean(first.innerText || first.textContent || '');
                    }
                    await wait(200);
                }
                return '';
            };
            const startedAt = Date.now();
            while (Date.now() - startedAt < 15000) {
                if (await openAllFilters()) {
                    await wait(2000);
                    const modal = document.querySelector('[role="dialog"]');
                    const scroller = modal ? (modal.querySelector('.artdeco-modal__content') || modal) : null;
                    if (scroller) {
                        scroller.scrollTop = Math.round(scroller.scrollHeight * 0.5);
                        await wait(400);
                    }
                    
                    const selectFilterOption = async (searchText) => {
                        const target = Array.from(modal.querySelectorAll('label, span, p')).find(el => clean(el.innerText || el.textContent || '') === clean(searchText));
                        if (target) {
                            const checkbox = target.closest('li, div, label')?.querySelector('input[type="checkbox"]');
                            if (checkbox && !checkbox.checked) {
                                checkbox.click();
                                await wait(300);
                            } else if (!checkbox) {
                                target.click();
                                await wait(300);
                            }
                        }
                    };

                    // Experience levels: Entry level, Associate, Mid-Senior level
                    if (scroller) scroller.scrollTop = 200; await wait(300);
                    await selectFilterOption('Entry level');
                    await selectFilterOption('Associate');
                    await selectFilterOption('Mid-Senior level');

                    // Job type: Full-time
                    if (scroller) scroller.scrollTop = 500; await wait(300);
                    await selectFilterOption('Full-time');

                    // Easy Apply: On
                    if (scroller) scroller.scrollTop = scroller.scrollHeight * 0.7; await wait(300);

                    const toggleStartedAt = Date.now();
                    let easyApplyToggle = null;
                    while (Date.now() - toggleStartedAt < 6000) {
                        easyApplyToggle = findEasyApplyToggle(modal || document);
                        if (easyApplyToggle) break;
                        await wait(200);
                    }
                    if (!easyApplyToggle) return { ok: false, error: 'Easy Apply toggle not found in filters modal.' };
                    if (!isToggleOn(easyApplyToggle)) {
                        easyApplyToggle.scrollIntoView?.({ block: 'center' });
                        await wait(200);
                        clickToggle(easyApplyToggle);
                        await wait(600);
                    }
                    
                    const showResultsButton = findShowResultsButton();
                    if (!showResultsButton) return { ok: false, error: 'Show results button not found in filters modal.' };
                    showResultsButton.click();
                    await wait(1200);

                    const fillStartedAt = Date.now();
                    while (Date.now() - fillStartedAt < 10000) {
                        const { keywordInput, locationInput } = getSearchInputs();
                        if (keywordInput && locationInput) {
                            fillInput(keywordInput, keyword);
                            await wait(250);
                            fillInput(locationInput, location);
                            await wait(450);
                            await pickLocationSuggestion();
                            await wait(500);
                            const searchButton = findSearchButton();
                            if (searchButton) searchButton.click();
                            return { ok: true, keyword, location, filterOpened: true, easyApplyEnabled: true };
                        }
                        await wait(250);
                    }
                    return { ok: false, error: 'Search inputs not found after applying filters.' };
                }
                await wait(250);
            }
            return { ok: false, error: 'Could not open All filters.' };
        },
        args: [params]
    });
    if (!result?.ok) throw new Error(result?.error || 'LinkedIn search setup failed.');
    return result;
}


async function exportLogsCsv() {
    return { ok: true, skipped: true, reason: 'csv_export_disabled' };
}

const DEFAULT_REGEX_ANSWERS = [
    { pattern: '*why do you want to work*', type: 'text', answer: '' },
    { pattern: '*accomplishments*', type: 'text', answer: '' }
];

chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.get(['profiles', 'activeProfileId', 'profileData', 'settings', 'abbyParams', 'abbyApplyMode', 'abbyApplyStats', 'savedRegexAnswers'], (result) => {
        const next = {};

        if (!result.profiles || !result.profiles.length) {
            const profile = { id: 'default', name: 'Default' };
            next.profiles = [profile];
            next.activeProfileId = profile.id;
            next.profileData = { profileName: profile.name };
        }

        if (!result.settings) {
            next.settings = { autopilotEnabled: true };
        }

        if (!result.abbyParams) {
            next.abbyParams = DEFAULT_PARAMS;
        } else {
            // Merge any new default customRegex entries into existing stored params
            const stored = result.abbyParams;
            const existing = Array.isArray(stored.customRegex) ? stored.customRegex : [];
            const merged = Array.from(new Set([...existing, ...DEFAULT_PARAMS.customRegex]));
            if (merged.length !== existing.length) {
                next.abbyParams = Object.assign({}, stored, { customRegex: merged });
            }
        }
        if (!result.abbyApplyMode) next.abbyApplyMode = 'auto';
        if (!result.abbyApplyStats) next.abbyApplyStats = { auto: 0, manual: 0 };

        // Merge new default regex answer patterns into existing (preserving user's custom answers)
        const existingRegex = Array.isArray(result.savedRegexAnswers) ? result.savedRegexAnswers : [];
        const existingPatterns = new Set(existingRegex.map(e => e.pattern));
        const newEntries = DEFAULT_REGEX_ANSWERS.filter(e => !existingPatterns.has(e.pattern));
        if (newEntries.length) next.savedRegexAnswers = [...existingRegex, ...newEntries];

        chrome.storage.local.set(next);
    });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    (async () => {
        switch (message?.type) {
            case 'abby:get-params': {
                const params = await loadParams();
                sendResponse({ ok: true, params });
                return;
            }
            case 'abby:save-params': {
                const params = await saveParams(message.params || {});
                sendResponse({ ok: true, params });
                return;
            }
            case 'abby:open-search': {
                const params = await saveParams(message.params || {});
                const store = await chrome.storage.local.get(['settings']);
                await chrome.storage.local.set({
                    settings: Object.assign({}, store.settings || {}, { autopilotEnabled: true })
                });
                const tab = await chrome.tabs.create({
                    url: buildSearchUrl(params),
                    active: false
                });
                await waitForTabComplete(tab.id);
                await runLinkedInSearchSetup(tab.id, params);
                sendResponse({ ok: true, tabId: tab.id, params });
                return;
            }
            case 'abby:start-apply': {
                const targetTabId = message.tabId || sender.tab?.id;
                if (!targetTabId) throw new Error('No target tab for apply.');
                await chrome.tabs.get(targetTabId);
                const res = await chrome.tabs.sendMessage(targetTabId, { type: 'abby:start-auto-apply' });
                sendResponse(Object.assign({ ok: true }, res || {}));
                return;
            }
            case 'abby:set-theme': {
                const theme = message.theme === 'light' ? 'light' : 'dark';
                await chrome.storage.local.set({ abbyTheme: theme });
                const tabs = await chrome.tabs.query({ url: ['https://www.linkedin.com/jobs/*'] });
                await Promise.all(tabs.map(async tab => {
                    try {
                        await chrome.tabs.sendMessage(tab.id, { type: 'abby:set-theme', theme });
                    } catch { }
                }));
                sendResponse({ ok: true, theme });
                return;
            }
            case 'abby:export-logs-csv': {
                const result = await exportLogsCsv();
                sendResponse(result);
                return;
            }
            case 'abby:update-dev-tasks': {
                const tabs = await chrome.tabs.query({ url: ['https://www.linkedin.com/jobs/*'] });
                await Promise.all(tabs.map(async tab => {
                    try {
                        await chrome.tabs.sendMessage(tab.id, { type: 'abby:update-dev-tasks', tasks: message.tasks });
                    } catch { }
                }));
                sendResponse({ ok: true });
                return;
            }
            default:
                sendResponse({ ok: false, error: 'unknown_message' });
        }
    })().catch(err => {
        sendResponse({ ok: false, error: err.message || String(err) });
    });
    return true;
});
